NS_ASSUME_NONNULL_BEGIN

@interface UMONCustomEventBuilder : NSObject
@property (nonatomic, retain) NSString* category;
@property (nonatomic, retain) NSString* type;
@property (nonatomic, retain) NSDictionary* userInfo;
@end

@interface UMONCustomEvent : NSObject
@property (strong) NSString* category;
@property (strong) NSString* type;
@property (strong) NSDictionary* userInfo;
-(instancetype)initWithBuilder:(UMONCustomEventBuilder*)builder;
+(instancetype)build:(void (^)(UMONCustomEventBuilder *))buildBlock;
@end

NS_ASSUME_NONNULL_END
